/*
 * capabilities.h
 */

#ifndef KINIT_CAPABILITIES_H
#define KINIT_CAPABILITIES_H

int drop_capabilities(const char *caps);

#endif						/* KINIT_CAPABILITIES_H */
