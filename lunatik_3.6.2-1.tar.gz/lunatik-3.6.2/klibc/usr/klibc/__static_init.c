#define SHARED 0
#include "libc_init.c"
