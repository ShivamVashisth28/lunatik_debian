#define SHARED 1
#include "libc_init.c"
