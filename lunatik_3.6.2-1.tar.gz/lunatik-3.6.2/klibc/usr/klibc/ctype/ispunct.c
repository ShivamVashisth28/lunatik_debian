#include "ctypefunc.h"
CTYPEFUNC(ispunct)
