/*
 * execl.c
 */

#define NAME execl
#define EXEC_P 0
#define EXEC_E 0
#include "exec_l.c"
